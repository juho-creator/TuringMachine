	#include "TuringMachine.h"
	#include <iostream>

	using namespace Turing;

	int index = 0;


	// Move <--> Char
	char moveToChar(Move move)
	{
		switch (move) {
		case Move::NONE:
			return '*';
		case Move::LEFT:
			return 'l';
		case Move::RIGHT:
			return 'r';
		default:
			return '?';
		}
	}
	
	Move stringToMove(const std::string& move)
	{
		if (move == "l" || move == "L") return Move::LEFT;
		if (move == "r" || move == "R") return Move::RIGHT;
		return Move::NONE;
	}




	/* Transition */
	Transition::Transition(const std::string& curr_s, char read_s, char write_s, Move m, const std::string& next_s)
		: curr_state{ curr_s }, read_symbol{ read_s }, write_symbol{ write_s }, move{ m }, next_state{ next_s }
	{
	}

	void Transition::print(std::ostream& os) const
	{
		os << curr_state << " ";
		os << read_symbol << " ";
		os << write_symbol << " ";
		os << (move == Move::LEFT ? 'l' : (move == Move::RIGHT ? 'r' : '*')) << " ";
		os << next_state;
	}




	/* Table */
	Table::Table() = default;
	Table::~Table() = default;

	void Table::addTransition(const std::string& curr_s, char read_s, char write_s, Move move, const std::string& next_s)
	{
		table.emplace_back(curr_s, read_s, write_s, move, next_s);
	}

	void Table::print(std::ostream& os) const
	{
		int index = 0;
		for (const auto& row : table) {
			std::cout << "[" << index << "]: ";
			row.print(os);
			std::cout << std::endl;
			index++;
		}
	}

	void Table::clear()
	{
		table.clear();
	}

	Transition* Table::findTransition(const std::string& curr_s, char read_s)
	{
		for (const auto& row : table) {
			// Exact Match (Both state and symbol)
			if (row.getCurrState() == curr_s && (row.getReadSymbol() == read_s || row.getReadSymbol()== WILDCARD_SYMBOL))
			{
				return new Transition(row.getCurrState(), row.getReadSymbol(), row.getWriteSymbol(), row.getMove(), row.getNextState());
			}
			
			// WildCard Match (Partially Matched rule
			if (row.getCurrState() == std::string(1, WILDCARD_SYMBOL) && (row.getReadSymbol() == read_s || row.getReadSymbol()==WILDCARD_SYMBOL))
			{
				return new Transition(row.getCurrState(), row.getReadSymbol(), row.getWriteSymbol(), row.getMove(), row.getNextState());
			}
			
		}
		return nullptr;
	}

	void Table::initialize(const std::string& rule_script)
	{
		table.clear();  // Clear the existing table entries

		std::istringstream script_stream(rule_script);  // Create a stream from the rule script string
		std::string line;

		// Read the script line by line
		while (std::getline(script_stream, line)) {
			line = Util::stripComment(line);  // Remove comments from the line

			// Remove leading whitespace
			line.erase(line.begin(), std::find_if(line.begin(), line.end(), [](int ch) {
				return !std::isspace(ch);
				}));

			// Remove trailing whitespace
			line.erase(std::find_if(line.rbegin(), line.rend(), [](int ch) {
				return !std::isspace(ch);
				}).base(), line.end());

			if (Util::isWhiteLine(line)) continue;  // Skip empty or whitespace-only lines

			std::istringstream line_stream(line);  // Create a stream from the processed line
			std::string curr_s, next_s, move_str;
			char read_s, write_s;

			// Parse the line for transition components
			if (line_stream >> curr_s >> read_s >> write_s >> move_str >> next_s) {
				Move move = stringToMove(move_str);  // Convert move string to Move enum
				addTransition(curr_s, read_s, write_s, move, next_s);  // Add the transition to the table
			}
		}
	}

	bool Table::load(const std::string& path)
	{
		table.clear();  // Clear the existing table entries

		std::ifstream file(path);  // Attempt to open the file at the specified path
		if (!file) {
			std::cerr << "Error: Unable to open file " << path << std::endl;  // Print error message if file cannot be opened
			return false;  // Return false indicating failure to load
		}

		// Read the entire file content into a string
		std::string script((std::istreambuf_iterator<char>(file)), std::istreambuf_iterator<char>());

		initialize(script);  // Initialize the table with the script read from the file
		return true;  // Return true indicating successful load
	}




	/* Tape */
	void Tape::initialize(const std::string& s)
	{
		resize(s.size()); // Resize internal storage to match the size of string s
		for (int i = 0; i < s.size(); ++i) { // Loop through each character in the string
			elem[i] = s[i]; // Copy each character from string s to the internal storage array elem
		}
	}

	void Tape::print(std::ostream& os) const
	{
		for (int i = 0; i < sz; ++i) {
			os << elem[i];
		}
	}

	bool Tape::read(int i, char& c) const
	{
		if (i >= 0 && i < sz) {
			c = elem[i];
			return true;
		}
		return false;
	}

	bool Tape::write(int i, char c)
	{
		if (i >= 0 && i < sz) {
			elem[i] = c;
			return true;
		}
		return false;
	}

	void Tape::clear()
	{
		sz = 0;
	}

	void Tape::push_back(char c)
	{
		if (sz == space) reserve(sz ? 2 * sz : 1);
		elem[sz++] = c;
	}

	void Tape::push_front(char c)
	{
		if (sz == space) reserve(sz ? 2 * sz : 1);
		for (int i = sz; i > 0; --i) {
			elem[i] = elem[i - 1];
		}
		elem[0] = c;
		++sz;
	}


	// Constructor & Destructor
	Tape::Tape() noexcept : sz(0), space(0), elem(nullptr) {}

	Tape::Tape(const Tape& t) : sz(t.sz), space(t.space), elem(new char[t.space])
	{
		std::copy(t.elem, t.elem + t.sz, elem);
	} // Copy constructor

	Tape::Tape(Tape&& t) noexcept : sz(t.sz), space(t.space), elem(t.elem)
	{
		t.sz = 0;
		t.space = 0;
		t.elem = nullptr;
	}

	Tape::~Tape() noexcept
	{
		delete[] elem;
	} // Destructor

	
	// Assignment Operators
	Tape& Tape::operator=(const Tape& t)
	{
		if (this == &t) return *this; // self-assignment check
		char* new_elem = new char[t.space];
		std::copy(t.elem, t.elem + t.sz, new_elem);
		delete[] elem;
		elem = new_elem;
		sz = t.sz;
		space = t.space;
		return *this;
	}

	Tape& Tape::operator=(Tape&& t) noexcept
	{
		if (this == &t) return *this; // self-assignment check
		delete[] elem;
		elem = t.elem;
		sz = t.sz;
		space = t.space;
		t.elem = nullptr;
		t.sz = 0;
		t.space = 0;
		return *this;
	}


	// Memory Management
	void Tape::reserve(size_t newalloc)
	{
		if (newalloc <= space) return;
		char* new_elem = new char[newalloc];
		for (int i = 0; i < sz; ++i) {
			new_elem[i] = elem[i];
		}
		delete[] elem;
		elem = new_elem;
		space = static_cast<int>(newalloc);
	}

	void Tape::resize(size_t newsize)
	{
		reserve(newsize);
		sz = static_cast<int>(newsize);
	}

	int Tape::size() const
	{
		return sz;
	}

	int Tape::capacity() const
	{
		return space;
	}




	/* Machine class */
	void Machine::initTape(const std::string& initial_symbols) {
		tape.initialize(initial_symbols);
	}

	void Machine::initTable(const std::string& rule_script) {
		table.initialize(rule_script);
	}

	bool Machine::loadTable(const std::string& path) {
		return table.load(path);
	}

	void Machine::start(const std::string& start_state, const std::string& accept_state, const std::string& reject_state) {
		current_state = start_state;
		this->accept_state = accept_state;
		this->reject_state = reject_state;
		current_pos = 0;
		current_mode = Mode::NORMAL;
	}

	bool Machine::step() {
		if (current_mode != Mode::NORMAL) {
			return false;  // Machine is not in a state to execute steps
		}

		// Read the current symbol at the tape head position
		char current_symbol;
		if (!tape.read(current_pos, current_symbol)) {
			current_symbol = '_'; // Use empty symbol if out of bounds
		}

		// Find the appropriate transition based on the current state and symbol
		Transition* transition = table.findTransition(current_state, current_symbol);
		if (transition == nullptr) {
			current_mode = Mode::ERROR; // No valid transition found, set mode to ERROR
			return false;
		}

		// Update the current state	
		current_state = transition->getNextState();

		// Check if the machine has reached the accept or reject states
		if (current_state == accept_state) {
			current_mode = Mode::ACCEPT;
			return false;
		}

		if (current_state == reject_state) {
			current_mode = Mode::REJECT;
			return false;
		}

		// Write the new symbol to the tape, if specified in the transition
		if (transition->getWriteSymbol() != '*') {
			tape.write(current_pos, transition->getWriteSymbol());
		}

		// Move the tape head according to the transition direction
		if (transition->getMove() == Move::LEFT) {
			if (current_pos == 0) {
				// Extend the tape to the left
				tape.push_front('_');
			}
			else {
				--current_pos;
			}
		}
		else if (transition->getMove() == Move::RIGHT) {
			++current_pos;
			if (current_pos == tape.size()) {
				// Extend the tape to the right
				tape.push_back('_');
			}
		}

		return true;
	}



