#include <iostream>
using namespace std;

extern void testTable();	 // Set of transition rules in table (Arbitrary Numbers) 
extern void testTape();		 // Strip of tape extendable in both left and right direction
extern void testMachine();   // Turing mahcine updating symbol on table based on table values

int main()
{
	//testTable();
	//testTape();
	testMachine();
}